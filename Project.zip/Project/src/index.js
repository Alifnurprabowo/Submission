/*
        jangan ubah kode di bawah ini ya!
*/

import "regenerator-runtime";
import "bootstrap/dist/css/bootstrap.min.css";
import "./styles/main.css";
import "./script/component/app-bar.js";
import main from "./script/main.js";

document.addEventListener("DOMContentLoaded", main);