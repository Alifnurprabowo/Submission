import './component/meal-list.js';
import '../data/data-source.js';


const main = () => {
        const mealListElement = document.querySelector("meal-list");
  
    const onButtonSearchClicked = () => {
        
        DataSource.searchMeal(searchElement.value)
        .then(renderResult)
        .catch(fallbackResult)
        
    };
  
    const renderResult = results => {
        mealListElement.meals = results;
    };
  
    const fallbackResult = message => {
        mealListElement.renderError(message);
    };
  
    searchElement.clickEvent = onButtonSearchClicked;
 };





    const getMeal = () => {
        fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${keyword}`)
         .then(response => {
             return response.json();
         })
         .then(responseJson => {
            if(responseJson.error) {
                showResponseMessage(responseJson.message);
            } else {
                renderAllMeals(responseJson.meals);
            }
         })
         .catch(error => {
             showResponseMessage(error);
         })
    };
    
    const insertMeal = (meal) => {
    fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${keyword}/add`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-Auth-Token": "12345"
        },
        body: JSON.stringify(meal)
    })
    .then(response => {
        return response.json();
    })
    .then(responseJson => {
        showResponseMessage(responseJson.message);
        getMeal();
    })
    .catch(error => {
        showResponseMessage(error);
    })
};


    /*
        jangan ubah kode di bawah ini ya!
    */

   const renderAllMeals = (meals) => {
    const listMealElement = document.querySelector("#listMeal");
    listMealElement.innerHTML = "";

    meals.forEach();

    
};

const showResponseMessage = (message = "Check your internet connection") => {
    alert(message);
};

    document.addEventListener("DOMContentLoaded", () => {

        const inputMealNama = document.querySelector("#inputMealNama");
        const inputMealInstruksi = document.querySelector("#inputMealInstruksi");
        const buttonSave = document.querySelector("#buttonSave");
        const onButtonSearchClicked = document.querySelector("#buttonSearch")
        

        buttonSave.addEventListener("click", function () {
            const meal = {
                kode: Number.parseInt(inputMealKode.value),
                nama: inputMealNama.value,
                instruksi: inputMealInstruksi.value
            };
            insertMeal(meal)
        });
        onButtonSearchClicked.addEventListener("click", function () {
            const meal = {
                kode: Number.parseInt(inputMealKode.value),
                nama: inputMealNama.value,
                instruksi: inputMealInstruksi.value
            };
            onButtonSearchClicked(meal)
        });
        getMeal();
    });


export default main;
